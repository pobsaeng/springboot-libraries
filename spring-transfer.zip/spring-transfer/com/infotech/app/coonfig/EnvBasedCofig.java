package com.infotech.app.coonfig;

public interface EnvBasedCofig {
 void setup();
}
