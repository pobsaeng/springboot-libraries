Full documentation available at: 

http://numberformat.wordpress.com/2013/02/16/log4j2-configuration-with-multiple-web-applications/

