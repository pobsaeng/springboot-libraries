import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shippers',
  templateUrl: './shippers.component.html',
  styleUrls: ['./shippers.component.css']
})
export class ShippersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
