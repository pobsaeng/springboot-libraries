import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-purchaseorders',
  templateUrl: './purchaseorders.component.html',
  styleUrls: ['./purchaseorders.component.css']
})
export class PurchaseordersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
