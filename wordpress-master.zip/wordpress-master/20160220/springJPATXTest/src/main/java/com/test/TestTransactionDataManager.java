package com.test;

public interface TestTransactionDataManager {
	public abstract Number writeData(String data);
}