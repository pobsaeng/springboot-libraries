Full Documentation available at:

http://numberformat.wordpress.com/2009/09/01/jndi-configuration-on-apache-tomcat-6-0/

TODO: move this to the wordpress repository.
