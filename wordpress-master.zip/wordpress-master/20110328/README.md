Full Documentation available at: http://numberformat.wordpress.com/2011/03/28/using-datamanagers-to-perform-crud-using-ibatis/
