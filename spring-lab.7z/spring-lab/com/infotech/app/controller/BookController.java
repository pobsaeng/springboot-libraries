package com.infotech.app.controller;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.infotech.app.injection.DbInjection;
import com.infotech.app.injection.ErrorInjection;
import com.infotech.app.injection.MsgInjection;
import com.infotech.app.model.Book;
import com.infotech.app.repositories.BookRepository;

@RestController
public class BookController {
	private static final Logger logger = LoggerFactory.getLogger(BookController.class);
	
	@PersistenceContext
	private EntityManager entityManager;
	
	@Autowired
	private BookRepository bookRepository;
	
	@Autowired
	private DataSource dataSource;

	private JdbcTemplate jdbcTemplate;

	@Autowired
	public void setDataSource(final DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	@Autowired
	private ErrorInjection errorInj;

	public ErrorInjection getErrorInj() {
		return this.errorInj;
	}
	
	@Autowired
	private DbInjection dbInj;

	public DbInjection getDbInj() {
		return this.dbInj;
	}

	@Autowired
	private MsgInjection msgInj;

	public MsgInjection getMsgInj() {
		return this.msgInj;
	}

	@GetMapping("/")
	public String hello() throws Exception {
		String production = getDbInj().getMessage() + " [ URL: " + getDbInj().getDatasource() + ", Username: "
				+ getDbInj().getUsername() + ", Password: " + getDbInj().getPassword() + ", Database: "
				+ dataSource.getConnection().getCatalog() + "]";
		System.out.println(production);
		return production;
	}
	
	@GetMapping("/inject/message")
	public String getJsonText() {
		logger.info("message!!!!!");
		String message = getErrorInj().getMsgError() + "," + getErrorInj().getMsgTable() + "," + getErrorInj().getMsgTitle();
		return message;
	}

	@GetMapping("/find/all/books")
	public List<Book> findAll() {
		List<Book> books = jdbcTemplate.query("select * from book", new BeanPropertyRowMapper(Book.class));
		return books;
	}
	@GetMapping("/find/book/withJPQL/{number}")
	public Book findBookByIdWithJPQL(@PathVariable("number") Integer number) {
		Book book = bookRepository.findBookByIdWithJPQL(number);
		return book;
	}	
	@GetMapping("/find/all/withJPQL")
	public List<Book> getAllBookWithJPQL() {
		List<Book> books = bookRepository.findAllBookWithJPQL(new Sort(Sort.Direction.DESC, "id"));
		return books;
	}
	public int countRowsInTable(String tableName) {
		Integer result = jdbcTemplate.queryForObject("SELECT COUNT(0) FROM " + tableName, Integer.class);
		return (result != null ? result : 0);
	}
	@GetMapping("/find/book/{stock}/{price}")
	public List<Book> getBookByIdAndPriceParams(@PathVariable("stock") Integer stock, @PathVariable("price") Integer price) {
		List<Book> books = bookRepository.findBookByIdAndPriceParams(stock, price);
		return books;
	}
	@GetMapping("/find/book/{number}")
	public List<Book> getBookById(@PathVariable("number") Integer number) {
		List<Book> books = bookRepository.findBookById(number);
		return books;
	}
	@GetMapping("/find/updatebook/{id}/{title}")
	public void getupdateBookForNameNative(@PathVariable("id") Integer id, @PathVariable("title") String title) {
		System.out.println(id+", "+title);
		bookRepository.updateBookForNameNative(title, id);
	}
	@GetMapping("/find/book/withNQ/{id}")
	public List<Book> getNativeNameQuery(@PathVariable("id") Integer id) {
		List<Book> books = entityManager.createNamedQuery("findByIdwithNQ").setParameter("id", id).getResultList();
		return books;
	}
	
	@GetMapping("/all/jpadata")
	public List<Book> getBookModel() {

		String qry = "SELECT * from book";
		Query query = entityManager.createNativeQuery(qry, Book.class);

		@SuppressWarnings("unchecked")
		List<Book> daoDtolist = query.getResultList();
		
		return daoDtolist;
	}
}
