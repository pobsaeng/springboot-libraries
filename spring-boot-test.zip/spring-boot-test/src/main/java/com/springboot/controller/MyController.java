package com.springboot.controller;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.injection.DbInjection;
import com.springboot.injection.ErrorInjection;
import com.springboot.injection.MsgInjection;
import com.springboot.model.Book;

@RestController
public class MyController {

	@Autowired
	private DataSource dataSource;

	private JdbcTemplate jdbcTemplate;

	@Autowired
	public void setDataSource(final DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	@Autowired
	private DbInjection dbInj;

	public DbInjection getDbInj() {
		return this.dbInj;
	}

	@Autowired
	private ErrorInjection errorInj;

	public ErrorInjection getErrorInj() {
		return this.errorInj;
	}

	@Autowired
	private MsgInjection msgInj;

	public MsgInjection getMsgInj() {
		return this.msgInj;
	}

	@GetMapping("/")
	public String hello() throws Exception {
		String production = getDbInj().getMessage() + " [ URL: " + getDbInj().getDatasource() + ", Username: "
				+ getDbInj().getUsername() + ", Password: " + getDbInj().getPassword() + ", Database: "
				+ dataSource.getConnection().getCatalog() + "]";
		System.out.println(production);
		return production;
	}

	@GetMapping("/all/book")
	public List<Book> findAll() {

		List<Book> books = jdbcTemplate.query("select * from book", new BeanPropertyRowMapper(Book.class));
		for (Book book : books) {
			System.out.println(book.getTitle());
			System.out.println(book.getAuthors());
			System.out.println(book.getStock());
			System.out.println(book.getPrice());
		}

		return books;
	}

	@GetMapping("/inject/message")
	public String getJsonText() {
		String message = getErrorInj().getMsgError() + "," + getErrorInj().getMsgTable() + "," + getErrorInj().getMsgTitle();
		return message;
	}
}