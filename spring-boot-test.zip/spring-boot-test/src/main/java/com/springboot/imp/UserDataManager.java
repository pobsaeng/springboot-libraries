package com.springboot.imp;

import java.io.Serializable;
import java.util.Random;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import com.springboot.model.Book;

public class UserDataManager extends CrudDataManagerImpl<Book, Serializable> {

	@PersistenceContext
	protected EntityManager entityManager;

	public Long getUserCount() {
		return entityManager.createNamedQuery("getCount", Long.class).getSingleResult();
	}

	public Book getRandom() {
		Long count = getUserCount();
		Long random = getRandomNumberInRange(0, count - 1);

		Book emp = entityManager.createNamedQuery("getAll", Book.class).setFirstResult(random.intValue())
				.setMaxResults(1).getSingleResult();

		return emp;
	}

	private static Long getRandomNumberInRange(long min, long max) {
		Random r = new Random();
		return r.longs(min, (max + 1)).findFirst().getAsLong();
	}
}
