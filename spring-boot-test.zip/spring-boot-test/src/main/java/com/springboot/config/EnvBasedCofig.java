package com.springboot.config;

public interface EnvBasedCofig {
	void setup();
}