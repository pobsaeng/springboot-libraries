package com.springboot.app;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.springboot.config.EnvBasedCofig;

@Configuration
@EnableAutoConfiguration
@ComponentScan(basePackages = { "com.springboot" })
@SpringBootApplication
public class SpringBootProfilesAppApplication implements CommandLineRunner {

	@Autowired
	private DataSource dataSource;

	@Autowired
	private EnvBasedCofig envBasedCofig;

	public static void main(String[] args) {
		SpringApplication.run(SpringBootProfilesAppApplication.class, args);
	}

	@Override
	public void run(String... arg0) throws Exception {
		System.out.println("------------------------------------------");
		System.out.println("Catalog = " + dataSource.getConnection().getCatalog());
		System.out.println("------------------------------------------");

		envBasedCofig.setup();
	}
}